import pandas as pd
import numpy as np
import torch
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

def load_and_inspect(path):
    # 1. Load data
    df = pd.read_csv(path,
                     parse_dates=['Time'],
                     encoding='utf-8')
    # 2. Quick EDA
    print(df.info())
    print(df.describe().T[['min','max','mean','std']])
    return df

def feature_engineering(df):
    # 3. Day of month & plot avg close
    df['Day'] = df['Time'].dt.day
    daily = df.groupby('Day')['Close'].mean()
    plt.figure(figsize=(8,4))
    plt.plot(daily.index, daily.values, marker='o')
    plt.title('Avg Close by Day'); plt.xlabel('Day'); plt.ylabel('Price')
    plt.grid(True); plt.show()
    return df

def preprocess_and_sequence(df, features, target, seq_len=30):
    # 4. Encode & scale
    df[target] = (df[target]=='YES').astype(int)
    scaler = StandardScaler()
    df[features] = scaler.fit_transform(df[features])
    
    # 5. Build sequences
    data = df[features + [target]].to_numpy()
    X = np.stack([data[i:i+seq_len, :-1] 
                  for i in range(len(data)-seq_len)], axis=0)
    y = data[seq_len:, -1].reshape(-1,1)
    return X, y

def split_and_tensor(X, y, train_ratio=0.8, val_ratio=0.1):
    n = len(X)
    i1 = int(n * train_ratio)
    i2 = int(n * (train_ratio + val_ratio))
    splits = (
      (X[:i1], y[:i1]),
      (X[i1:i2], y[i1:i2]),
      (X[i2:], y[i2:])
    )
    # To torch.Tensor
    return tuple(torch.tensor(a, dtype=torch.float32) 
                 for part in splits for a in part)

if __name__ == "__main__":
    path = "./GU_M5.csv"
    df = load_and_inspect(path)
    df = feature_engineering(df)

    features = ["Open","High","Low","Close","Volume",
                "Body_Size","Upper_Wick","Lower_Wick",
                "RSI","MACD_Main","MACD_Signal"]
    target = "Up 200"

    X, y = preprocess_and_sequence(df, features, target, seq_len=30)
    X_train, y_train, X_val, y_val, X_test, y_test = split_and_tensor(X, y)

    print("Shapes:",
          "Train", X_train.shape, y_train.shape,
          "Val",   X_val.shape,   y_val.shape,
          "Test",  X_test.shape,  y_test.shape)
