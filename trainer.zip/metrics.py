# metrics.py
import numpy as np
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score,
    recall_score, roc_auc_score, average_precision_score
)
import torch.nn as nn
import torch

def compute_metrics(y_true, y_prob):
    """
    y_true: numpy array 0/1
    y_prob: numpy array float in [0,1]
    """
    y_pred = (y_prob > 0.5).astype(int)

    # Always tính loss trên tensor
    loss = nn.BCELoss()(
        torch.tensor(y_prob, dtype=torch.float32),
        torch.tensor(y_true, dtype=torch.float32)
    ).item()

    # accuracy và AUC thì an toàn
    acc = accuracy_score(y_true, y_pred)
    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = float("nan")

    # precision/recall/f1 với zero_division=0
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec  = recall_score(y_true, y_pred, zero_division=0)
    f1   = f1_score(y_true, y_pred, zero_division=0)

    # average precision (precision-recall AUC)
    try:
        ap = average_precision_score(y_true, y_prob)
    except ValueError:
        ap = float("nan")

    return {
        "loss": loss,
        "acc" : acc,
        "auc" : auc,
        "prec": prec,
        "rec" : rec,
        "f1"  : f1,
        "ap"  : ap
    }
