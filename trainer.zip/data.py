# data.py
import os
import pandas as pd
import numpy as np
import torch
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from torch.utils.data import TensorDataset, DataLoader

def load_and_inspect(path):
    df = pd.read_csv(path, parse_dates=['Time'], encoding='utf-8')
    print(df.info())
    print(df.describe().T[['min','max','mean','std']])
    return df

def feature_engineering(df):
    df['Day'] = df['Time'].dt.day
    daily = df.groupby('Day')['Close'].mean()
    plt.figure(figsize=(8,4))
    plt.plot(daily.index, daily.values, marker='o')
    plt.title('Avg Close by Day'); plt.xlabel('Day'); plt.ylabel('Price')
    plt.grid(True); plt.show()
    return df

def preprocess_and_sequence(df, features, target, seq_len=30):
    df[target] = (df[target] == 'YES').astype(int)
    scaler = StandardScaler()
    df[features] = scaler.fit_transform(df[features])

    data = df[features + [target]].to_numpy()
    X = np.stack([data[i:i+seq_len, :-1] 
                  for i in range(len(data)-seq_len)], axis=0)
    y = data[seq_len:, -1].reshape(-1,1)
    return X, y

def split_and_tensor(X, y, train_ratio=0.8, val_ratio=0.1):
    n = len(X)
    i1 = int(n * train_ratio)
    i2 = int(n * (train_ratio + val_ratio))

    splits = (
        (X[:i1], y[:i1]),
        (X[i1:i2], y[i1:i2]),
        (X[i2:], y[i2:])
    )
    tensors = []
    for arr, lab in splits:
        tensors.append(torch.tensor(arr, dtype=torch.float32))
        tensors.append(torch.tensor(lab, dtype=torch.float32))
    return tensors  # [X_train, y_train, X_val, y_val, X_test, y_test]

def get_loader(X, y, cfg, shuffle=False):
    ds = TensorDataset(X.to(cfg.device), y.to(cfg.device))
    return DataLoader(ds, batch_size=cfg.batch_size, shuffle=shuffle)
