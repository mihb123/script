# main.py
import torch
from config import Config
from data import (
    load_and_inspect,
    feature_engineering,
    preprocess_and_sequence,
    split_and_tensor,
    get_loader
)
from model import TimeSeriesModel
from trainer import Trainer
from metrics import compute_metrics

def main():
    cfg = Config()
    torch.manual_seed(cfg.seed)

    # --- Data pipeline ---
    df = load_and_inspect("./GU_M5.csv")
    # df = feature_engineering(df)

    features = ["Open","High","Low","Close","Volume",
                "Body_Size","Upper_Wick","Lower_Wick",
                "RSI","MACD_Main","MACD_Signal"]
    target = "Up 200"

    X, y = preprocess_and_sequence(df, features, target, seq_len=30)
    X_train, y_train, X_val, y_val, X_test, y_test = split_and_tensor(X, y)

    cfg.input_size = X_train.shape[2]

    train_loader = get_loader(X_train, y_train, cfg, shuffle=True)
    val_loader   = get_loader(X_val,   y_val,   cfg)
    test_loader  = get_loader(X_test,  y_test,  cfg)

    # --- Model & training ---
    model   = TimeSeriesModel(cfg)
    trainer = Trainer(model, cfg)
    history = trainer.fit(train_loader, val_loader)

    # --- Final evaluation on test set ---
    model.load_state_dict(torch.load(cfg.ckpt_path))
    test_loss, test_probs, test_labels = trainer.eval_one_epoch(test_loader)
    metrics = compute_metrics(test_labels, test_probs)
    print("\n=== Test metrics ===")
    for k,v in metrics.items():
        print(f"{k.upper():<5}: {v:.4f}")

if __name__ == "__main__":
    main()
