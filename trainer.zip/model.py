# model.py
import torch.nn as nn

class TimeSeriesModel(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.lstm = nn.LSTM(
            cfg.input_size, cfg.hidden_size, cfg.num_layers,
            batch_first=True,
            dropout=cfg.dropout if cfg.num_layers > 1 else 0
        )
        self.fc = nn.Linear(cfg.hidden_size, 1)
        self._init_weights()

    def _init_weights(self):
        for n, p in self.lstm.named_parameters():
            if "weight_hh" in n: nn.init.orthogonal_(p)
            elif "weight_ih" in n: nn.init.kaiming_normal_(p)
        nn.init.xavier_uniform_(self.fc.weight)

    def forward(self, x):
        _, (h_n, _) = self.lstm(x)
        return self.fc(h_n[-1])
