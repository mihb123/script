# config.py
import torch
from dataclasses import dataclass

@dataclass
class Config:
    seed: int = 42
    device: str = "cuda" if torch.cuda.is_available() else "cpu"

    # model
    input_size: int = None    # gán sau khi load data
    hidden_size: int = 128
    num_layers: int = 3
    dropout: float = 0.3

    # training
    lr: float = 1e-3
    weight_decay: float = 1e-5
    batch_size: int = 128
    max_epochs: int = 100
    patience: int = 15

    # paths
    ckpt_path: str = "saved_models/best_model.pth"
