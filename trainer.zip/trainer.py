# trainer.py

import os
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import trange, tqdm
from metrics import compute_metrics

class Trainer:
    def __init__(self, model, cfg):
        self.cfg = cfg
        self.device = torch.device(cfg.device)
        self.model = model.to(self.device)
        self.criterion = nn.BCEWithLogitsLoss()
        # Khởi tạo optimizer dùng self.model.parameters()
        self.optimizer = optim.AdamW(
            self.model.parameters(),
            lr=cfg.lr,
            weight_decay=cfg.weight_decay
        )
        # Scheduler
        self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            factor=0.5,
            patience=5
        )

    def train_one_epoch(self, loader):
        self.model.train()
        losses = []
        # Bọc loader bởi tqdm với bar_format tuỳ chỉnh
        pbar = tqdm(
            loader,
            desc="Train",
            leave=False,
            bar_format='{desc}: {percentage:3.0f}% | {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]'
        )
        for Xb, yb in pbar:
            Xb, yb = Xb.to(self.device), yb.to(self.device)
            logits = self.model(Xb).squeeze()
            loss = self.criterion(logits, yb.view(-1))

            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()

            losses.append(loss.item())
            # cập nhật loss vào bên phải thanh progress
            pbar.set_postfix(loss=f"{loss.item():.4f}")
        return np.mean(losses)

    def eval_one_epoch(self, loader):
        self.model.eval()
        losses, probs, labels = [], [], []
        with torch.no_grad():
            for Xb, yb in loader:
                Xb, yb = Xb.to(self.device), yb.to(self.device)
                logits = self.model(Xb).squeeze()
                losses.append(self.criterion(logits, yb.view(-1)).item())
                p = torch.sigmoid(logits).cpu().numpy()
                probs.extend(p.tolist())
                labels.extend(yb.cpu().numpy().flatten().tolist())
        return np.mean(losses), np.array(probs), np.array(labels)

    def fit(self, train_loader, val_loader):
        os.makedirs(os.path.dirname(self.cfg.ckpt_path), exist_ok=True)
        best_val_loss, wait = float('inf'), 0
        history = {'train_loss': [], 'val_loss': [], 'val_acc': [], 'val_auc': []}

        for epoch in trange(1, self.cfg.max_epochs + 1, desc="Epochs"):
            start = time.time()

            # Train + Val
            tr_loss = self.train_one_epoch(train_loader)
            val_loss, val_probs, val_labels = self.eval_one_epoch(val_loader)
            val_metrics = compute_metrics(val_labels, val_probs)
            # Scheduler
            self.scheduler.step(val_loss)

            # Lưu lịch sử
            history['train_loss'].append(tr_loss)
            history['val_loss'].append(val_loss)
            history['val_acc'].append(val_metrics['acc'])
            history['val_auc'].append(val_metrics['auc'])

            # Tính it/s
            duration = time.time() - start
            its = len(train_loader) / duration

            # In ra
            print(
                f"\nEpoch {epoch}/{self.cfg.max_epochs}  "
                f"Train Loss={tr_loss:.4f}  Val Loss={val_loss:.4f}  "
                f"Val Acc={val_metrics['acc']:.4f}  Val AUC={val_metrics['auc']:.4f}  "
                f"{its:.1f} it/s"
            )

            # Checkpoint + Early Stopping
            if val_loss < best_val_loss - 1e-4:
                best_val_loss, wait = val_loss, 0
                torch.save(self.model.state_dict(), self.cfg.ckpt_path)
                print("✔️  Saved best model.")
            else:
                wait += 1
                if wait >= self.cfg.patience:
                    print("⏹️  Early stopping.")
                    break

        return history
